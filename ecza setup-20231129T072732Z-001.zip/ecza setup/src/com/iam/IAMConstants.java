  package com.iam;

  public class IAMConstants {
    public static final String HRMS = "Oracle HRMS";
    public static final String AD = "Active Directory";
    public static final String PRE_HIRE = "PreHired";
    public static final String ACTIVE = "Active";
    public static final String INACTIVE = "Inactive";
  }